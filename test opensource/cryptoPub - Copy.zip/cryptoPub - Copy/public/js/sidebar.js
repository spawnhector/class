function expand(){
    alert('yes')
}

$('.expandBtn').on('click', function () {
    alert('hi')
})