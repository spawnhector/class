document.write('<div id="tester" style="display: none">an advertisement</div>');
