<?php

namespace App\Http\Livewire\User;

use Livewire\Component;
use Livewire\WithPagination;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Collection;
use Illuminate\Pagination\LengthAwarePaginator;

class Faucet extends Component
{
    // use WithPagination;

    public $faucetType,
    $faucet,
    $data,
    $disable_admin_panel,
    $faucetList;

    protected 
    $antibotlinks;

    protected function getListeners()
    {
        return ['take' => 'test'];
    }

    public function alert($link){
        $this->dispatchBrowserEvent('name-updated', ['newName' => 4]);
    }
    
    public function render()
    {
        $this->faucetType();
        
                // dd($this->antibotlinks);
        return view('livewire.user.faucet',['antibotlinks'=>$this->antibotlinks]);
    }

    public function faucetType(){
        if (isset($_POST['faucet'])) {
            $type = ddecrypt($_POST['faucet']);
            $this->faucet = $type;

            if ($type == 'FaucetPay') {
                $list = curlOut('https://faucetpay.io/api/listv1/faucetlist','GET');
                if (isset($list['status']) && isset($list['status']) == 200) {
                    $this->faucetList = $list['list_data']['normal'];
                } else {
                    # code...
                }
                // dd($list);
            }
            
            if ($type == 'CryptoPubFaucet') {
            }
        }
    }

    public function paginate($items, $options = [], $perPage = 5, $page = null)
    {
        $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
        $items = $items instanceof Collection ? $items : Collection::make($items);
        return new LengthAwarePaginator($items->forPage($page, $perPage), $items->count(), $perPage, $page, $options);
    }
}
