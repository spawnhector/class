<?php

namespace App\Http\Livewire\User;

use Livewire\Component;

class CryptopubFaucet extends Component
{
    public $faucetList;

    public function faucetType(){
        if (isset($_POST['faucet'])) {
            $type = ddecrypt($_POST['faucet']);
            $this->faucet = $type;

            if ($type == 'CryptoPub') {
                $sql = sql();
                $dbtable_prefix = prefix();

                $q = $sql->prepare("SELECT * FROM ".$dbtable_prefix."cryptopub_faucet");
                $q->execute();
                $array = [];
                while ($row = $q->fetch()) {
                    array_push($array,$row);
                }
                // dd($array);
                $this->faucetList = $array;
            }
        }
    }

    public function render()
    {
        $this->faucetType();
        return view('livewire.user.cryptopub-faucet');
    }


}
