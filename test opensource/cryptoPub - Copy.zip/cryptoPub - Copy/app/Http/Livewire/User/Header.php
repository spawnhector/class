<?php

namespace App\Http\Livewire\User;

use Livewire\Component;

class Header extends Component
{
    public 
    $liveCoin;

    protected $listeners = [
        'refresh'=>'$refresh'
    ];

    public function logout(){
        dd('yes');
    }


    public function render()
    {
        return view('livewire.user.header');
    }
}
