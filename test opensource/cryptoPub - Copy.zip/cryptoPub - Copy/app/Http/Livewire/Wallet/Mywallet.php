<?php

namespace App\Http\Livewire\Wallet;

use Livewire\Component;

class Mywallet extends Component
{
    public function render()
    {
        return view('livewire.wallet.mywallet');
    }
}
