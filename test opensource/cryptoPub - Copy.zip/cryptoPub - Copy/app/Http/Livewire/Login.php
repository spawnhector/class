<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class Login extends Landing
{
    public $email;
    public $password;
    public $type;

    protected $listeners = [
        'setype'=>'setype'
    ];

    public function submit(){
        if ($this->type == 'Earner') {
            $user = User::where('email','=',$this->email)->get();
            if (count($user) != 0) {
                $data = [
                    'email'=>$this->email,
                    'password'=>$this->password
                ];
                
                if (Auth::attempt($data)) {
                    redirect()->route('dashboard');
                } else {
                    # code...
                }
                
                // Auth::attempt($data)
                // ? redirect()->route('dashboard')
                // : dd('no');
            } else {
                $check = count(User::where('role','=','Earner')->get());
                $check++;
                $umi = str_pad($check, 6, "0", STR_PAD_LEFT); 
                User::create([
                    'name'=> 'CPUSER'.$umi.'',
                    'email'=> $this->email,
                    'password'=> Hash::make($this->password),
                    'UCI'=> 'CP'.$umi.'',
                    'role'=>'Earner'
                ])
                ? redirect()->route('dashboard')
                : dd('no');
            }
        }
        
    }

    public function setype($type){
        $this->type = $type;
    }
    public function render()
    {
        return view('livewire.login');
    }
}
