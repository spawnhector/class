<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Landing extends Component
{
    public $selectVal = 'get started';
    public $login_btn;
    public $accounType = 'get started';

    public function selectSite($site){
        $this->selectVal = $site;
        $this->login_btn = true;
        $this->accounType = $site;
        $this->emit('setype',$site);
    }

    public function getAccount(){
        return $this->accounType;
    }
    
    public function render()
    {
        return view('livewire.landing');
    }
}
