<?php
use App\Http\Livewire\Landing;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Hash;

const submit_btn = 'flex
items-center
justify-center
w-full
px-10
py-4
text-base
font-medium
text-center text-white
transition
duration-500
ease-in-out
transform
bg-blue-400
rounded-xl
hover:bg-blue-500
focus:outline-none
focus:ring-2
focus:ring-offset-2
focus:ring-blue-500';

const password_field = 'block
w-full
px-5
py-3
text-base text-neutral-600
placeholder-black-300
transition
duration-500
ease-in-out
transform
border border-transparent
rounded-lg
bg-gray-50
focus:outline-none
focus:border-transparent
focus:ring-2
focus:ring-white
focus:ring-offset-2
focus:ring-offset-gray-300';

const email_field = 'block
w-full
px-5
py-3
text-base text-neutral-600
placeholder-black-300
transition
duration-500
ease-in-out
transform
border border-transparent
rounded-lg
bg-gray-50
focus:outline-none
focus:border-transparent
focus:ring-2
focus:ring-white
focus:ring-offset-2
focus:ring-offset-gray-300';

const login_svg = '<?xml version="1.0" encoding="iso-8859-1"?>
<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" style="width: 27px;" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<g>
	<g>
		<g>
			<path d="M110.933,221.786c-4.719,0-8.533,3.823-8.533,8.533v51.2c0,4.71,3.814,8.533,8.533,8.533s8.533-3.823,8.533-8.533v-51.2
				C119.467,225.609,115.652,221.786,110.933,221.786z"/>
			<path d="M503.467,247.386H216.849l70.784-70.775c3.336-3.337,3.336-8.73,0-12.066c-3.337-3.336-8.73-3.336-12.066,0
				l-85.333,85.325c-0.273,0.273-0.384,0.623-0.606,0.922c-0.461,0.589-0.947,1.152-1.229,1.843
				c-0.444,1.05-0.666,2.159-0.666,3.277v0.009c0,0.162,0.085,0.299,0.094,0.452c0.051,0.947,0.188,1.894,0.555,2.782
				c0.444,1.075,1.092,2.039,1.911,2.842l85.274,85.291c1.664,1.664,3.849,2.5,6.033,2.5c2.185,0,4.369-0.836,6.033-2.5
				c3.336-3.328,3.336-8.73,0-12.066l-70.75-70.767h286.583c4.719,0,8.533-3.823,8.533-8.533
				C512,251.209,508.186,247.386,503.467,247.386z"/>
			<path d="M111.855,2.309L31.164,34.59C8.448,43.004,0,54.422,0,76.719v358.477c0,22.298,8.448,33.715,30.967,42.061l81.05,32.427
				c4.011,1.519,8.038,2.287,11.972,2.287c17.161,0,29.611-14.336,29.611-34.091V34.053C153.6,9.775,134.246-6.114,111.855,2.309z
				 M136.533,477.88c0,10.18-5.043,17.024-12.544,17.024c-1.86,0-3.874-0.401-5.794-1.118l-81.092-32.452
				c-16.102-5.965-20.036-11.102-20.036-26.138V76.719c0-15.036,3.934-20.164,20.233-26.206l80.734-32.29
				c2.082-0.785,4.087-1.186,5.956-1.186c7.501,0,12.544,6.835,12.544,17.016V477.88z"/>
			<path d="M332.8,298.586c-4.719,0-8.533,3.823-8.533,8.533v128c0,14.114-11.486,25.6-25.6,25.6H179.2
				c-4.719,0-8.533,3.823-8.533,8.533s3.814,8.533,8.533,8.533h119.467c23.526,0,42.667-19.14,42.667-42.667v-128
				C341.333,302.409,337.519,298.586,332.8,298.586z"/>
			<path d="M178.133,51.119h120.533c14.114,0,25.6,11.486,25.6,25.6v128c0,4.71,3.814,8.533,8.533,8.533
				c4.719,0,8.533-3.823,8.533-8.533v-128c0-23.526-19.14-42.667-42.667-42.667H178.133c-4.719,0-8.533,3.823-8.533,8.533
				S173.414,51.119,178.133,51.119z"/>
		</g>
	</g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
';
function dhash($string){
	return Hash::make($string);
}

function dhashCheck($string,$hash){
	return Hash::check($string,$hash);
}

function dencrypt($string){
	return Crypt::encryptString($string);
}

function ddecrypt($string){
	try {
		return Crypt::decryptString($string);
	} catch (DecryptException $e) {
		return $e;
	}
}

function curlOut($url,$method){
	$curl = curl_init();

	curl_setopt_array($curl, array(
	CURLOPT_URL => $url,
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => '',
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 0,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => $method,
	));

	$response = json_decode(curl_exec($curl),true);

	curl_close($curl);
	return $response;
}


function domain($apiPort){
    $split = explode(':',$_SERVER['HTTP_HOST']);
    $split[1] = $apiPort;
    $host = $split[0].':'.$split[1];
    $link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ?
                "https" : "http") . "://" . $host;
  
    return $link;
}


function faucetbox_path(){
	return "C:/xampp/htdocs/xampp/test opensource/cryptoPub/resources/views/faucet/faucetinabox/";
}

function currentPage(){
    return $_SERVER['REQUEST_URI'];
}

function sql(){
	
	// include('faucet/faucetinabox/config');
	require('C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views\faucet\faucetinabox\config.php');
	try {
		$sql = new PDO($dbdsn, $dbuser, $dbpass, array(PDO::ATTR_PERSISTENT => true,
													   PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
	} catch(PDOException $e) {
		if ($display_errors) die("Can't connect to database. Check your config.php. Details: ".$e->getMessage());
		else die("Can't connect to database. Check your config.php or set \$display_errors = true; to see details.");
	}

	return $sql;
}

function prefix(){
	return 'faucetinabox_';
}

function session_prefix(){
	require(''.faucetbox_path().'config.php');
	$session_prefix=md5($dbuser.'-'.$dbname.'-'.$dbtable_prefix);
	return $session_prefix='_'.substr($session_prefix, 0, 8);
}


function adminPage(){
    echo '
    <form action="/adminfaucet" method="post">
        '.csrf_field().'
        <button type="submit">admin page</button>
    </form>
    ';
}

function redirectP($route,$label,$data=''){

	if (!empty($data)) {
		echo '
		<form action="'.route($route).'" method="post">
			'.csrf_field().'
			'.$data.'
			<button type="submit">'.$label.'</button>
		</form>
		';
	} else {
		echo '
		<form action="'.route($route).'" method="post">
			'.csrf_field().'
			<button type="submit">'.$label.'</button>
		</form>
		';
	}
}

function redirectPr($route,$label,$data=''){

	if (!empty($data)) {
		return '
		<form action="'.route($route).'" method="post">
			'.csrf_field().'
			'.$data.'
			<button type="submit">'.$label.'</button>
		</form>
		';
	} else {
		return '
		<form action="'.route($route).'" method="post">
			'.csrf_field().'
			<button type="submit">'.$label.'</button>
		</form>
		';
	}
}

function antibotlink(){
	// require ''.faucetbox_path().'libs/antibotlinks.php';
	require_once(''.faucetbox_path().'libs/antibotlinks.php');
	$antibotlinkk = new antibotlinks(true, 'ttf,otf');// true if GD is on on the server, false is less secure, also you can enable ttf and/or otf
	// dd($antibotlinkk);
	if (array_key_exists('address', $_POST)) {
		if (!$antibotlinkk->check()) {
			// suggested (it is way better to have more word universes than more links)
			// 4 links should be enough to discourage (and make easy to detect) brute-force
			$antibotlinkk->generate(4, true);// number of links once they fail, the second param MUST BE true
		}
	} else {
		// suggested (it is way better to have more word universes than more links)
		// 4 links should be enough to discourage (and make easy to detect) brute-force
		$antibotlinkk->generate(4);// initial number of links
	}
	return $antibotlinkk;
}

function user_data(){
	
	require_once(''.faucetbox_path().'index.php');
	// dd($data);
	return $data;
}