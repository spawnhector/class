<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('extends.welcome');
});

Route::get('/wallet', function () {
    return view('extends.wallet');
});

Route::get('/dashboard', function () {
    return view('extends.user.index');
})->name('dashboard');

Route::get('/profile', function () {
    return view('extends.user.profile');
})->name('profile');

Route::post('/faucet', function () {
    return view('extends.user.faucet');
})->name('faucet');

Route::post('/adminfaucet', function () {
    return view('extends.admin.faucet');
})->name('adminFaucet');

Route::post('/admincheck', function () {
    return view('faucet.faucetinabox.admincheck');
})->name('admincheck');
