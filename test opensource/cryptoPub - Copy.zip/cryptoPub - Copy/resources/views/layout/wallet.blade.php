
<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="{{asset('css/style.css')}}">
      <link rel="stylesheet" href="{{asset('css/responsive.css')}}">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.assets/js/2.9.3/Chart.css">
      <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
      <link rel="stylesheet" href="{{asset('css/owl.carousel.min.css')}}">
      <link rel="stylesheet" href="{{asset('css/all.min.css')}}">
      <link rel="shortcut icon" href="assets/images/favicon.png">
   </head>
   <body class="theme-defalt">
      <style>
         .wallet-transaction{
            margin: 0px 30px;
         }
         @media screen and (max-width: 1199px) and (min-width: 992px){
            .wallet-transaction-box .wallet-transaction-balance{
               float: right !important;
              display: inherit !important;
              width: auto !important;
            }
         }
      </style>
      @yield('body')
      <script src="{{asset('js/jquery.min.js')}}"></script>
      <script src="{{asset('js/bootstrap.min.js')}}"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
      <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
      <script src="{{asset('js/custom.js')}}"></script>
   </body>
</html>