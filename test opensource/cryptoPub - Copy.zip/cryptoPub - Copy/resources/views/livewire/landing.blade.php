<main class="valign-wrapper">
    <span class="container ml-16 grey-text text-lighten-1 ">

      <p class="flow-text">Welcome to</p>
      <h1 class="title grey-text text-lighten-3">CryptoPUB</h1>

      <blockquote class="flow-text">Earn Crypto By Completing Small Task And Playing Games.</blockquote>

      <div class="center-align flex">
        <!-- Dropdown Trigger -->
        <a class="btn dropdown-button mt-4" href="" data-activates="exams">{{$accounType}}<i class="material-icons right">expand_more</i></a>

        <!-- Dropdown Structure -->
        <ul id="exams" class="dropdown-content mt-4">
          <li><a wire:click="selectSite('Earner')">Earner</a></li>
          <li><a wire:click="selectSite('Creator')">Creator</a></li>
          <li><a wire:click="selectSite('Affiliate')">Affiliate</a></li>
        </ul>

        @if ($login_btn)
          <x-modal :formhead=true account='{{$accounType}}'>
          </x-modal>
        @endif

 


      </div>
      <div class="Container1">
        <div class="Subscribe">
          <h3>Subscribe to our newsletter</h3>
          <p>Weekly animation tutorials delivered straight to your inbox</p>
          <form action="#">
            <input type="text" placeholder="Email Address" />
            <button>Subscribe</button>
          </form>
          <div class="Loading">
            <div class="LoadingDot"></div>
            <div class="LoadingDot"></div>
            <div class="LoadingDot"></div>
            <div class="LoadingDot"></div>
            <span>Subscribing</span>
          </div>
          <div class="Complete">
            <div class="Tick">
      
              <svg width="32px" height="25px" viewBox="0 0 32 25">
                    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                        <g id="Artboard" transform="translate(-384.000000, -217.000000)" fill-rule="nonzero" fill="#FFFFFF">
                            <g id="Group" transform="translate(360.000000, 189.000000)">
                                <path d="M27.4142136,40.5857864 C26.633165,39.8047379 25.366835,39.8047379 24.5857864,40.5857864 C23.8047379,41.366835 23.8047379,42.633165 24.5857864,43.4142136 L34,52.8284271 L55.4142136,31.4142136 C56.1952621,30.633165 56.1952621,29.366835 55.4142136,28.5857864 C54.633165,27.8047379 53.366835,27.8047379 52.5857864,28.5857864 L34,47.1715729 L27.4142136,40.5857864 Z" id="Path-2"></path>
                            </g>
                        </g>
                    </g>
                </svg>
            </div>
            <h4>Thank you for subscribing</h4>
            <span>You will receive a confirmation email shortly</span>
          </div>
        </div>
      </div>
    </span>
  </main>

  <div class="fixed-action-btn">
    <a href="#message" class="modal-trigger btn btn-large btn-floating amber waves-effect waves-light">
      <i class="large material-icons">message</i>
    </a>
  </div>

  <div id="message" class="modal modal-fixed-footer">
    <div class="modal-content">
      <h4>Contact</h4>
      <p>coming soon...</p>
    </div>
    <div class="modal-footer">
      <a href="" class="modal-action modal-close waves-effect btn-flat">close</a>
    </div>
  </div>