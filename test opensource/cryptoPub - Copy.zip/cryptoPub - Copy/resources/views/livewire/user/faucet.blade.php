<div>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <h3>
            Faucet
        </h3>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="breadcrumb-item"><a href="#">Members</a></li>
            <li class="breadcrumb-item active"> Faucet</li>
        </ol>
    </div>

    <div class="col-12">
        <div class="box">
            <div class="box-header">
                <h4 class="box-title">{{$faucet}}</h4>
            </div>
        </div>
        {{-- @if ($faucetList)
            @foreach ($faucetList as $key=>$item)
                <div class="col-12">
                    <div class="box">
                        <div class="box-header with-border">
                            
                            <div class="flexbox mb-1">
                                <span>
                                    <i class="cc {{$key}}" title="{{$key}}" style="font-size: 41px"></i>
                                    {{$key}}
                                </span>
                                <span class="text-primary font-size-40">{{count($item)}}<span class="text-primary font-size-20"> Faucets</span></span>
                                
                            </div>
                                
                        </div>
                        <div class="box-body p-0">
                            <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 450px;"><div class="media-list media-list-hover media-list-divided  scroll" style="height: 450px; width: auto;">
                                @php
                                    $data[$key] = $this->paginate(
                                        $item,
                                        [
                                            'path' => request()->url(), 
                                            'query' => request()->query()
                                        ]
                                    );
                                @endphp
                                @foreach ($data[$key] as $faucet)
                                    <div class="media media-single ribbon-box">
                                        <div class="media-body ">
                                            <div class="ribbon-two ribbon-two-primary">
                                                @if ($faucet['is_enabled'] == "1")
                                                    <span style="background: green;">Active</span>
                                                @endif
                                                @if ($faucet['total_users_paid'] > "100")
                                                    <span style="background: #007bff;">Paying</span>
                                                @endif
                                            </div>
                                            <h6><a ><span style="font-size: 23px;">{{$faucet['name']}}</span></a></h6>
                                            <div class="list-container flex mt-2">
                                                <small class="text-fader" style="display: grid;margin-left:20px">
                                                    <span class="text-primary font-size-18"></i> <span class="" style="color: whitesmoke">Reward Amount :  <span class="text-primary " style="font-size: 13px">up-to<i class="fa fa-level-up" aria-hidden="true"></i></span> {{$faucet['reward']}} satoshi</span></span>
                                                    <span class="text-primary font-size-18"><i class="fa fa-money" aria-hidden="true"></i> <span class="font-size-17" style="color: whitesmoke">Paid Today :  {{$faucet['paid_today']}} {{$key}}</span></span>
                                                    <span class="text-primary font-size-18"><i class="far fa-user"></i> <span class="font-size-17" style="color: whitesmoke">User's Paid Today :  {{$faucet['total_users_paid']}}</span></span>
                                                </small>
                                                <small class="text-fader" style="display: grid;margin-left:125px">
                                                    <span class="text-primary font-size-18"><i class="fas fa-users"></i> <span class="font-size-17" style="color: whitesmoke">Active Users {{$faucet['active_users']}}</span></span>
                                                    <span class="text-primary font-size-18">
                                                        <span class="font-size-17" style="color: whitesmoke">
                                                            <div class="progress progress-xxs mt-10 mb-0">
                                                            <div class="progress-bar" role="progressbar" style="width: {{$faucet['health']}}%; height: 4px;" aria-valuenow="{{$faucet['health']}}" aria-valuemin="0" aria-valuemax="100"></div>
                                                            </div>
                                                            <span class="text-primary font-size-18">
                                                                <i class="ti-heart"></i> 
                                                            </span>
                                                            Health {{$faucet['health']}}%
                                                        </span>
                                                    </span>
                                                    <span class="text-primary font-size-20"><i class="ti-timer"></i> <span class="font-size-17" style="color: whitesmoke">Reward Every ({{$faucet['timer_in_minutes']}} mins)</span></span>
                                                </small>
                                            </div>
                                        </div>

                                        <div class="media-right">
                                            <a class="btn btn-outline btn-white btn-sm" href="#"><span class=" font-size-18">Visit Faucet</span></a>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        <div class="slimScrollBar" style="background: rgb(0, 0, 0); width: 7px; position: absolute; top: 153px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 149.379px;"></div><div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
                        </div>
                    <div class="text-center bt-1 border-light p-2">
                        {{$data[$key]->links()}}
                    </div>
                    </div>
                </div>
            @endforeach
        @endif --}}
        {{-- {{dd($data)}} --}}

        @if ($faucet == 'FaucetPay')
            @php
                $count = 0;
            @endphp
            @if ($faucetList)
                @foreach ($faucetList as $key=>$item)
                    <div class="box">
                        <div class="box-header with-border">
                            <div class="flexbox mb-1">
                                <span>
                                    <i class="cc {{$key}}" title="{{$key}}" style="font-size: 41px"></i>
                                    {{$key}}
                                </span>
                                <span class="text-primary font-size-40">{{count($item)}}<span class="text-primary font-size-20"> Faucets</span></span>
                                
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div class="table-responsive">
                            <table id="faucetTable{{$count}}" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Reward</th>
                                        <th>Paid Today</th>
                                        <th>User's Paid Today</th>
                                        <th>Active Users</th>
                                        <th>Health</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($item as $faucet)
                                            <tr>
                                                <td>
                                                    <div class="faucet-link" onclick="alert('{{$faucet['name']}}')">
                                                        {{$faucet['name']}}
                                                    </div>
                                                    @if ($faucet['is_enabled'] == "1")
                                                        <span class="badge badge-pill badge-primary">Active</span>
                                                    @endif
                                                    @if ($faucet['total_users_paid'] > "100")
                                                        <span class="badge badge-pill badge-success">Paying</span>
                                                    @endif
                                                </td>
                                                <td>{{$faucet['reward']}} satoshi</td>
                                                <td>{{$faucet['paid_today']}} USD</td>
                                                <td>{{$faucet['total_users_paid']}}</td>
                                                <td>{{$faucet['active_users']}}</td>
                                                <td>
                                                    {{$faucet['health']}}%
                                                    <div class="progress progress-xxs mt-10 mb-0">
                                                        <div class="progress-bar" role="progressbar" style="width: {{$faucet['health']}}%; height: 4px;" aria-valuenow="{{$faucet['health']}}" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </td>
                                            </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Name</th>
                                        <th>Position</th>
                                        <th>Office</th>
                                        <th>Age</th>
                                        <th>Start date</th>
                                        <th>Salary</th>
                                    </tr>
                                </tfoot>
                            </table>
                            </div>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    @php
                        ++$count;
                    @endphp
                @endforeach
            @endif
    
            <script>
                $(function () {
                    "use strict";
                    for (let index = 0; index < {{$count}}; index++) {
                        $('#faucetTable'+index+'').DataTable();
                    }
                }); // End of use strict
            </script>
            <script>
                function alert(params) {
                    
                    !function($) {
                        "use strict";
        
                        var SweetAlert = function() {};
        
                        //examples 
                        SweetAlert.prototype.init = function() {
                        
                        //Parameter
                        
                        swal({   
                            title: "Redirecting To External Link.",   
                            text: "You will not be able to recover this imaginary file!", 
                            type: "warning",   
                            showCancelButton: true,   
                            confirmButtonColor: "#DD6B55",   
                            confirmButtonText: "Continue",   
                            cancelButtonText: "Go Back",   
                            closeOnConfirm: false,   
                            closeOnCancel: true 
                        }, function(isConfirm){   
                            if (isConfirm) {     
                                swal("Deleted!", "Your imaginary file has been deleted.", "success");   
                            } 
                        });
        
                        },
                        //init
                        $.SweetAlert = new SweetAlert, $.SweetAlert.Constructor = SweetAlert
                    }(window.jQuery),
        
                    //initializing 
                    function($) {
                        "use strict";
                        $.SweetAlert.init()
                    }(window.jQuery);
                }
            </script>
        @endif

        @if ($faucet == 'CryptoPubFaucet')
            @include('faucet.faucetinabox.index')
        @endif

        @if ($faucet == 'CryptoPub')
            @livewire('user.cryptopub-faucet')
        @endif
    </div>
    {{-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> --}}
    
</div>
