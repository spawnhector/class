<div>
    @php
        $count = 0;
        $old = '';
    @endphp
    @if ($faucetList)
        @foreach ($faucetList as $key=>$item)
            {{-- {{dd($item['service'])}} --}}
            @php
                $new = $item['service'];
            @endphp
            @if ($old != $new)
                <div class="box">
                    <div class="box-header with-border">
                        <div class="flexbox mb-1">
                            <span>
                                {{-- <i class="cc {{$key}}" title="{{$key}}" style="font-size: 41px"></i> --}}
                                {{$item['service']}}
                            </span>
                            {{-- <span class="text-primary font-size-40">{{count($item)}}<span class="text-primary font-size-20"> Faucets</span></span> --}}
                            
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                        <table id="cryptopubfaucetTable{{$count}}" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Currency</th>
                                    <th>Timer</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($faucetList as $faucets)
                                    @if ($item['service'] == $faucets['service'])
                                        <tr>
                                            <td>
                                                <div class="faucet-link">
                                                    @php
                                                        if ($sp = explode('<sup>',$faucets['name'])) {
                                                            redirectP('faucet', $sp[0],
                                                            "
                                                                <input type='hidden' name='faucet' value='".dencrypt('CryptoPubFaucet')."'>
                                                                <input type='hidden' name='cryptopubfaucet' value='".dencrypt($faucets['service'])."'>
                                                                <input type='hidden' name='faucet_service' value='".dencrypt($faucets['service'])."'>
                                                                <input type='hidden' name='faucet_name' value='".dencrypt($faucets['name'])."'>
                                                                <input type='hidden' name='faucet_apikey' value='".dencrypt($faucets['api_key'])."'>
                                                                <input type='hidden' name='faucet_currency' value='".dencrypt($faucets['currency'])."'>
                                                                <input type='hidden' name='faucet_rewards' value='".dencrypt($faucets['rewards'])."'>
                                                                <input type='hidden' name='faucet_short' value='".dencrypt($faucets['short'])."'>
                                                                <input type='hidden' name='faucet_timer' value='".dencrypt($faucets['timer'])."'>
                                                                <input type='hidden' name='faucet_referral' value='".dencrypt($faucets['referral'])."'>
                                                            ");
                                                        } else {
                                                            redirectP('faucet', $faucets['name'],
                                                            "
                                                                <input type='hidden' name='faucet' value='".dencrypt('CryptoPubFaucet')."'>
                                                                <input type='hidden' name='cryptopubfaucet' value='".dencrypt($faucets['service'])."'>
                                                                <input type='hidden' name='faucet_service' value='".dencrypt($faucets['service'])."'>
                                                                <input type='hidden' name='faucet_name' value='".dencrypt($faucets['name'])."'>
                                                                <input type='hidden' name='faucet_api_key' value='".dencrypt($faucets['api_key'])."'>
                                                                <input type='hidden' name='faucet_currency' value='".dencrypt($faucets['currency'])."'>
                                                                <input type='hidden' name='faucet_rewards' value='".dencrypt($faucets['rewards'])."'>
                                                                <input type='hidden' name='faucet_short' value='".dencrypt($faucets['short'])."'>
                                                                <input type='hidden' name='faucet_timer' value='".dencrypt($faucets['timer'])."'>
                                                                <input type='hidden' name='faucet_referral' value='".dencrypt($faucets['referral'])."'>
                                                                <input type='hidden' name='faucet_referral' value='".dencrypt($faucets['referral'])."'>
                                                            ");
                                                        }
                                                    @endphp
                                                </div>
                                                @if ($faucets['status'] == "1")
                                                    <span class="badge badge-pill badge-primary">Active</span>
                                                @endif
                                            </td>
                                            <td>{{$faucets['currency']}}</td>
                                            <td>{{$faucets['timer']}} mins</td>
                                            <td>
                                                @if ($faucets['status'] == "1")
                                                    <span class="">Paying</span>
                                                @else
                                                    <span class="">Disabled</span>
                                                @endif
                                            </td>
                                        </tr>
                                    @endif
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Name</th>
                                    <th>Currency</th>
                                    <th>Timer</th>
                                    <th>Status</th>
                                </tr>
                            </tfoot>
                        </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
            @endif
            @php
                ++$count;
                $old = $item['service'];
            @endphp
        @endforeach
    @endif

    <script>
        $(function () {
            "use strict";
            for (let index = 0; index < {{$count}}; index++) {
                $('#cryptopubfaucetTable'+index+'').DataTable();
            }
        }); // End of use strict
    </script>
    <script>
        function alert(params) {
            
            !function($) {
                "use strict";

                var SweetAlert = function() {};

                //examples 
                SweetAlert.prototype.init = function() {
                
                //Parameter
                
                swal({   
                    title: "Redirecting To External Link.",   
                    text: "You will not be able to recover this imaginary file!", 
                    type: "warning",   
                    showCancelButton: true,   
                    confirmButtonColor: "#DD6B55",   
                    confirmButtonText: "Continue",   
                    cancelButtonText: "Go Back",   
                    closeOnConfirm: false,   
                    closeOnCancel: true 
                }, function(isConfirm){   
                    if (isConfirm) {     
                        swal("Deleted!", "Your imaginary file has been deleted.", "success");   
                    } 
                });

                },
                //init
                $.SweetAlert = new SweetAlert, $.SweetAlert.Constructor = SweetAlert
            }(window.jQuery),

            //initializing 
            function($) {
                "use strict";
                $.SweetAlert.init()
            }(window.jQuery);
        }
    </script>
</div>
