
<div>
@props([
    'formhead'=> false,
    'component'=>'login',
    'account'
])
    <a class="btn1 dropdown-button mt-4" href="#login/signup"  style="position: absolute;left:230px">Continue To {{$account}}'s Account</a>
    <div id="login/signup" class="modalbg">
        <div class="dialog">
            <a href="#close" title="Close" class="close">X</a>
            <div>
                <div class="flex justify-center items-center flex-col mt-8">
                    
                    <div>
                        <div class="flex justify-center items-center flex-col mt-4">
                            @if ($formhead)
                                <div class="form-head"><h1 class="title grey-text text-lighten-3" style="font-size:32px;">CryptoPUB {{ $account }}</h1></div>
                            @endif
                            @livewire($component)
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
