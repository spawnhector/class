<div>
    {{-- {{dd($type)}} --}}
    @livewire($component)
</div>