@extends('layout/wallet')
@section('body')
    @livewireScripts
    @livewire('wallet.mywallet')
@endsection