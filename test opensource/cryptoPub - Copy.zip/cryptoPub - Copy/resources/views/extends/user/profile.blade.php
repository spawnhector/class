@extends('layout/user/index')
@section('body')
@livewire('user.profile')
@endsection