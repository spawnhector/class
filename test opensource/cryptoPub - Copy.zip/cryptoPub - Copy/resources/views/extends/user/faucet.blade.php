@extends('layout/user/index')
@section('body')
@livewire('user.faucet')
@endsection