@extends('layout/user/index')
@section('body')
@livewire('user.dashboard')
@endsection