@extends('layout/landing')
@section('body')
    @livewireScripts
    @livewire('landing')
@endsection