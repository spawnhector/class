<?php return array (
  'landing' => 'App\\Http\\Livewire\\Landing',
  'login' => 'App\\Http\\Livewire\\Login',
  'user.cryptopub-faucet' => 'App\\Http\\Livewire\\User\\CryptopubFaucet',
  'user.dashboard' => 'App\\Http\\Livewire\\User\\Dashboard',
  'user.faucet' => 'App\\Http\\Livewire\\User\\Faucet',
  'user.header' => 'App\\Http\\Livewire\\User\\Header',
  'user.index' => 'App\\Http\\Livewire\\User\\Index',
  'user.profile' => 'App\\Http\\Livewire\\User\\Profile',
  'user.setting' => 'App\\Http\\Livewire\\User\\Setting',
  'user.sidebar' => 'App\\Http\\Livewire\\User\\Sidebar',
  'wallet.mywallet' => 'App\\Http\\Livewire\\Wallet\\Mywallet',
);