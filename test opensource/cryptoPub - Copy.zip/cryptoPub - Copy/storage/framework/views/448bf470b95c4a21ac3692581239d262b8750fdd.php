<?php $__env->startSection('body'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.dashboard')->html();
} elseif ($_instance->childHasBeenRendered('7mEOIob')) {
    $componentId = $_instance->getRenderedChildComponentId('7mEOIob');
    $componentTag = $_instance->getRenderedChildComponentTagName('7mEOIob');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7mEOIob');
} else {
    $response = \Livewire\Livewire::mount('user.dashboard');
    $html = $response->html();
    $_instance->logRenderedChild('7mEOIob', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/user/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/extends/user/index.blade.php ENDPATH**/ ?>