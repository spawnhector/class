
<?php $__env->startSection('body'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.faucet')->html();
} elseif ($_instance->childHasBeenRendered('Gqbi25H')) {
    $componentId = $_instance->getRenderedChildComponentId('Gqbi25H');
    $componentTag = $_instance->getRenderedChildComponentTagName('Gqbi25H');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Gqbi25H');
} else {
    $response = \Livewire\Livewire::mount('user.faucet');
    $html = $response->html();
    $_instance->logRenderedChild('Gqbi25H', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/user/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/extends/user/faucet.blade.php ENDPATH**/ ?>