<div>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($component)->html();
} elseif ($_instance->childHasBeenRendered('zHVOQYS')) {
    $componentId = $_instance->getRenderedChildComponentId('zHVOQYS');
    $componentTag = $_instance->getRenderedChildComponentTagName('zHVOQYS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zHVOQYS');
} else {
    $response = \Livewire\Livewire::mount($component);
    $html = $response->html();
    $_instance->logRenderedChild('zHVOQYS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div><?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/components/login.blade.php ENDPATH**/ ?>