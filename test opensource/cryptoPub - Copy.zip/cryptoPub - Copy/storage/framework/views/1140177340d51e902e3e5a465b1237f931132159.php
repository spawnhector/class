<?php $attributes = $attributes->exceptProps([
    'formhead'=> false,
    'component'

]); ?>
<?php foreach (array_filter(([
    'formhead'=> false,
    'component'

]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <a class="btn1 dropdown-button mt-4" href="#login/signup"  style="position: absolute;left:230px">Continue To <?php echo e($account); ?>'s Account</a>
    <div id="login/signup" class="modalbg">
        <div class="dialog">
            <a href="#close" title="Close" class="close">X</a>
            <div>
                <div class="flex justify-center items-center flex-col mt-8">
                    
                    <div>
                        <div class="flex justify-center items-center flex-col mt-4">
                            <?php if($formhead): ?>
                                <div class="form-head"><h1 class="title grey-text text-lighten-3" style="font-size:32px;">CryptoPUB <?php echo e($account); ?></h1></div>
                            <?php endif; ?>
                            <x-login :component="$component" :type=>"<?php echo e($account); ?>"
                             <?php if (isset($__componentOriginal)): ?>
<?php $component = $__componentOriginal; ?>
<?php unset($__componentOriginal); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/components/my-modal.blade.php ENDPATH**/ ?>