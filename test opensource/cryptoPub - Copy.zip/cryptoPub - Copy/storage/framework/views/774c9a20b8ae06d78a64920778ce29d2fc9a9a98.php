<div>
    <div class="flex justify-center items-center flex-col mt-8">
        
        <div class="form-head"><h1 class="title grey-text text-lighten-3" style="font-size:32px;">CryptoPUB <?php echo e($accountty); ?></h1></div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('login-modal',[
          'component'=>'login-signup-form'
        ])->html();
} elseif ($_instance->childHasBeenRendered('ooxvZOf')) {
    $componentId = $_instance->getRenderedChildComponentId('ooxvZOf');
    $componentTag = $_instance->getRenderedChildComponentTagName('ooxvZOf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ooxvZOf');
} else {
    $response = \Livewire\Livewire::mount('login-modal',[
          'component'=>'login-signup-form'
        ]);
    $html = $response->html();
    $_instance->logRenderedChild('ooxvZOf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/components/login-signup-form.blade.php ENDPATH**/ ?>