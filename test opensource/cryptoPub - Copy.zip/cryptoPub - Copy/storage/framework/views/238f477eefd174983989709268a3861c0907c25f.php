<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../images/favicon.ico">

    <title></title>

    <!-- Bootstrap 4.0-->
    <link rel="stylesheet" href="<?php echo e(asset('css/user/bootstrap.min.css')); ?>">

    <!-- theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/user/sweetalert/sweetalert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/user/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/user/cryptocoins.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/user/cryptocoins-colors.css')); ?>">

    <!-- Admin skins -->
    <link rel="stylesheet" href="<?php echo e(asset('css/user/skin_color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/user/main.css')); ?>">
    
	<!-- owlcarousel-->
	<link rel="stylesheet" href="<?php echo e(asset('css/user/owl.carousel.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/user/datatables.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/scroll.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/user/owl.theme.default.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/user/font-awesome/font-awesome.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/user/material/materialdesignicons.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/user/themify/themify-icons.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="https://kit.fontawesome.com/1e7319fbc7.js" crossorigin="anonymous"></script>
    
    <!-- jQuery 3 -->
    <script src="<?php echo e(asset('js/user/jquery-3.3.1.js')); ?>"></script>

    <!-- fullscreen -->
    <script src="<?php echo e(asset('js/user/screenfull.js')); ?>"></script>

    <!-- popper -->
    <script src="<?php echo e(asset('js/user/popper.min.js')); ?>"></script>

    <!-- Bootstrap 4.0-->
    <script src="<?php echo e(asset('js/user/bootstrap.min.js')); ?>"></script>

    <!-- SlimScroll -->
    <script src="<?php echo e(asset('js/user/jquery.slimscroll.js')); ?>"></script>

    <!-- FastClick -->
    <script src="<?php echo e(asset('js/user/fastclick.js')); ?>"></script>

    <!-- Crypto Admin App -->
    <script src="<?php echo e(asset('js/user/template.js')); ?>"></script>

    <!-- Crypto Admin for demo purposes -->
    <script src="<?php echo e(asset('js/user/demo.js')); ?>"></script>
    <script src="<?php echo e(asset('js/user/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/user/widget-blog.js')); ?>"></script>
    <script src="<?php echo e(asset('js/user/list.js')); ?>"></script>
    <script src="<?php echo e(asset('js/user/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/user/sweetalert/sweetalert.min.js')); ?>"></script>
    
    
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="hold-transition dark-skin dark-sidebar sidebar-mini theme-yellow">
    <!-- Site wrapper -->
    <div class="wrapper">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.header')->html();
} elseif ($_instance->childHasBeenRendered('XvSbOEf')) {
    $componentId = $_instance->getRenderedChildComponentId('XvSbOEf');
    $componentTag = $_instance->getRenderedChildComponentTagName('XvSbOEf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XvSbOEf');
} else {
    $response = \Livewire\Livewire::mount('user.header');
    $html = $response->html();
    $_instance->logRenderedChild('XvSbOEf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <!-- Left side column. contains the logo and sidebar -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.sidebar')->html();
} elseif ($_instance->childHasBeenRendered('NCiTPlU')) {
    $componentId = $_instance->getRenderedChildComponentId('NCiTPlU');
    $componentTag = $_instance->getRenderedChildComponentTagName('NCiTPlU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NCiTPlU');
} else {
    $response = \Livewire\Livewire::mount('user.sidebar');
    $html = $response->html();
    $_instance->logRenderedChild('NCiTPlU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <div class="container-full">
                <div class="loader"></div>
              <?php echo $__env->yieldContent('body'); ?>
            </div>
        </div>
        <!-- /.content-wrapper -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.setting')->html();
} elseif ($_instance->childHasBeenRendered('WmAy6EO')) {
    $componentId = $_instance->getRenderedChildComponentId('WmAy6EO');
    $componentTag = $_instance->getRenderedChildComponentTagName('WmAy6EO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WmAy6EO');
} else {
    $response = \Livewire\Livewire::mount('user.setting');
    $html = $response->html();
    $_instance->logRenderedChild('WmAy6EO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <footer class="main-footer">
            <div class="pull-right d-none d-sm-inline-block">
                <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0)">FAQ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Purchase Now</a>
                    </li>
                </ul>
            </div>
            &copy; 2019 <a href="https://www.multipurposethemes.com/">Multi-Purpose Themes</a>. All Rights Reserved.
        </footer>

    </div>
    <!-- ./wrapper -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/layout/user/index.blade.php ENDPATH**/ ?>