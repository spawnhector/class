<div>
    <a class="btn dropdown-button mt-4" href="#login/signup"  style="position: absolute;left:230px">Continue To <?php echo e($accounType); ?>'s Account</a>
    <div id="login/signup" class="modalbg">
        <div class="dialog">
        <a href="#close" title="Close" class="close">X</a>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($component,
        [
            'accounType'=>$accounType
        ])->html();
} elseif ($_instance->childHasBeenRendered('82bZrBX')) {
    $componentId = $_instance->getRenderedChildComponentId('82bZrBX');
    $componentTag = $_instance->getRenderedChildComponentTagName('82bZrBX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('82bZrBX');
} else {
    $response = \Livewire\Livewire::mount($component,
        [
            'accounType'=>$accounType
        ]);
    $html = $response->html();
    $_instance->logRenderedChild('82bZrBX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/livewire/login-modal.blade.php ENDPATH**/ ?>