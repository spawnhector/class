<?php $attributes = $attributes->exceptProps([
    'errors' => false,
    'placeholder' => false,
    'type' => 'text'
]); ?>
<?php foreach (array_filter(([
    'errors' => false,
    'placeholder' => false,
    'type' => 'text'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<?php
    $classes = ($errors ?? false)
        ? 'form-input w-full p-4 pr-12 text-sm border-red-400 rounded-lg shadow-sm'
        : 'form-input w-full p-4 pr-12 text-sm border-grey-400 rounded-lg shadow-sm'
?>

<div>
    <input
    <?php echo e($attributes->merge([
        'class' => $classes
    ])); ?> 
    placeholder="<?php echo e($placeholder); ?>"
    type="<?php echo e($type); ?>">

    <?php if($errors): ?>
        <div class="m-1 font-thin text-red-600">
            <?php echo e($errors); ?>

        </div>
    <?php endif; ?>
    
</div><?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/components/input.blade.php ENDPATH**/ ?>