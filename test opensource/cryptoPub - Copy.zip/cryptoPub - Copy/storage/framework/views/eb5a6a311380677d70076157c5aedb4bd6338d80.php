
<?php $__env->startSection('body'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.profile')->html();
} elseif ($_instance->childHasBeenRendered('9Ztboha')) {
    $componentId = $_instance->getRenderedChildComponentId('9Ztboha');
    $componentTag = $_instance->getRenderedChildComponentTagName('9Ztboha');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9Ztboha');
} else {
    $response = \Livewire\Livewire::mount('user.profile');
    $html = $response->html();
    $_instance->logRenderedChild('9Ztboha', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/user/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/extends/user/profile.blade.php ENDPATH**/ ?>