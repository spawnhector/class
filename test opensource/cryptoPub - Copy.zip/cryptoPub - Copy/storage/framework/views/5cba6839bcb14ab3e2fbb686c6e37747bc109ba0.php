<div>

    <!-- wallet area -->
    <div class="wallet-area">
        <div class="wallet-area-warpper">
         <div id="loader-wrapper">
           <div id="loader"></div>
           <div class="loader-images"><img src="<?php echo e(asset('images/loader.svg')); ?>" alt="Loader"></div>
         </div>
           <div class="row">
              <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                 <div class="header-box">
                    <div class="header-logo">
                       <a href="dashboard.html"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo"></a>
                    </div>
                    <div class="header-nav-menu">
                       <i class="menu-responsive fas fa-bars"></i>
                       <ul>
                          <li><a href="dashboard.html"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                          <li class="active"><a href="wallet.html"><i class="fas fa-wallet"></i> My Wallet</a></li>
                          <li><a href="transfer-coin.html"><i class="fas fa-coins"></i> Transfer Coin</a></li>
                          <li><a href="transaction.html"><i class="fas fa-history"></i> Transaction</a></li>
                          <li><a href="profile.html"><i class="fas fa-user"></i> Profile</a></li>
                          <li><a href="#" data-toggle="modal" data-target="#logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                       </ul>
                       <div class="color-switcher">
                         <div class="toggle-button"><i class="fas fa-cog"></i></div>
                         <div class="color-theme-menu">
                           <h4>Color Switcher</h4>
                           <ul id="color-ul" class="clearfix">
                             <li class="color-li"><a class="theme-defalt" title="theme" href="#"></a></li>
                             <li class="color-li"><a class="theme-orrange" title="theme" href="#"></a></li>
                             <li class="color-li"><a class="theme-cyan" title="theme" href="#"></a></li>
                             <li class="color-li"><a class="theme-green" title="theme" href="#"></a></li>
                             <li class="color-li"><a class="theme-purple" title="theme" href="#"></a></li>
                             <li class="color-li"><a class="purple-pink" title="theme" href="#"></a></li>
                           </ul>
                         </div>
                       </div>
                       <div class="theme-color-swith">
                         <a href="JavaScript:Void(0)" onclick="changeMode()">Dark Mode</a>
                         <label class="switch">
                                             <input type="checkbox" id="theme-change" >
                                           <span class="slider round"></span>
                         </label>
                       </div>
                    </div>
                 </div>
                 <div class="wallet-area-right">
                    <div class="wallet-top-header clearfix">
                       <div class="wallet-top-header-left">
                          <div class="wallet-top-header-box">
                             <div class="header-wallet-ico" style="color: #87d682;"><i class="fas fa-wallet"></i></div>
                             <span>Total Balance</span>
                             <h3 style="color: #87d682;"><span>657.0378348945</span> USD</h3>
                          </div>
                          <!-- <div class="wallet-top-header-box">
                             <div class="header-wallet-ico" style="color: #7ad9e3;"><i class="fab fa-bitcoin"></i></div>
                             <span>Pending Balance</span>
                             <h3 style="color: #7ad9e3;"><span>87.749575978</span> BTC</h3>
                          </div> -->
                       </div>
                       <div class="wallet-top-header-right">
                          <div class="wallet-language-box">
                            <div class="dropdown">
                               <div class="select">
                                  <span><img class="flag-img" src="<?php echo e(asset('images/us.png')); ?>" alt="USA"> English</span> <i class="fas fa-caret-down"></i>
                               </div>
                               <input type="hidden" name="gender">
                               <div class="dropdown-menu">
                                 <ul class="language-dropdown">
                                    <li>
                                         <a href="#" class="lang-br lang-select" data-lang="en">
                                             <span><img class="flag-img" src="assets/images/flag/us.png" alt="USA"></span>English
                                         </a>
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|ar)" class="lang-br lang-select" data-lang="ar">
                                             <span><img class="flag-img" src="assets/images/flag/ae.png" alt="Arabic"></span>Arabic
                                         </a>    
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|de)" class="lang-br lang-select" data-lang="de">
                                             <span><img class="flag-img" src="assets/images/flag/de.png" alt="Germany"></span>Deutsch
                                         </a>    
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|it)" class="lang-br lang-select" data-lang="it">
                                             <span><img class="flag-img" src="assets/images/flag/it.png" alt="Italy"></span>Italiano
                                         </a>    
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|vi)" class="lang-br lang-select" data-lang="vn">
                                             <span><img class="flag-img" src="assets/images/flag/th.png" alt="Viet Nam"></span>Tiếng Việt
                                         </a>    
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|pt)" class="lang-br lang-select" data-lang="pt">
                                             <span><img class="flag-img" src="assets/images/flag/br.png" alt="Brazil"></span>Portuguese
                                         </a>    
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|es)" class="lang-br lang-select" data-lang="es">
                                             <span><img class="flag-img" src="assets/images/flag/es.png" alt="Spain"></span>español
                                         </a>    
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|zh-CN)" class="lang-br lang-select" data-lang="zh-CN">
                                             <span><img class="flag-img" src="assets/images/flag/cn.png" alt="China"></span>Chinese
                                         </a>    
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|ko)" class="lang-br lang-select" data-lang="ko">
                                             <span><img class="flag-img" src="assets/images/flag/kr.png" alt="Korea, Republic of"></span>한국어
                                         </a>    
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|ru)" class="lang-br lang-select" data-lang="ru">
                                             <span><img class="flag-img" src="assets/images/flag/ru.png" alt="Russia"></span>Русский
                                         </a>    
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|ja)" class="lang-br lang-select" data-lang="ja">
                                             <span><img class="flag-img" src="assets/images/flag/jp.png" alt="Japan"></span>日本語
                                         </a>    
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|hi)" class="lang-br lang-select" data-lang="hi">
                                             <span><img class="flag-img" src="assets/images/flag/in.png" alt="India"></span>Hindi
                                         </a>    
                                     </li>
                                     <li>
                                         <a href="#googtrans(en|th)" class="lang-br lang-select" data-lang="th">
                                             <span><img class="flag-img" src="assets/images/flag/th.png" alt="Thailand"></span>ภาษาไทย
                                         </a>    
                                     </li>
                                 </ul>
                               </div>
                            </div>
                          </div>
                          <div class="notification-box-area">
                            <div class="notification-box">
                              <i class="fas fa-bell"></i>
                              <span class="notification-active"></span>
                            </div>
                            <div class="notification-dropdown">
                              <div class="notification-header">
                                <h3>You have <strong>3</strong> new notifications.</h3>
                              </div>
                              <ul class="notification-list">
                                <li class="notification-success">
                                  <div class="notification-icon"><i class="fas fa-check-circle"></i></div>
                                  <div class="notification-content">
                                    <h3>Successful transaction of 0.01 BTC</h3>
                                    <h4>15 mins ago</h4>
                                  </div>
                                </li>
                                <li class="notification-pending">
                                  <div class="notification-icon"><i class="fas fa-exclamation-circle"></i></div>
                                  <div class="notification-content">
                                    <h3>4 of Pending Transactions!</h3>
                                    <h4>45 mins ago</h4>
                                  </div>
                                </li>
                                <li class="notification-cancel read-notification">
                                  <div class="notification-icon"><i class="fas fa-times-circle"></i></div>
                                  <div class="notification-content">
                                    <h3>Cancelled Transaction of 20 BTC</h3>
                                    <h4>1 hour ago</h4>
                                  </div>
                                </li>
                                <li class="notification-cancel read-notification">
                                  <div class="notification-icon"><i class="fas fa-times-circle"></i></div>
                                  <div class="notification-content">
                                    <h3>Cancelled Transaction of 5 BTC</h3>
                                    <h4>1 hour ago</h4>
                                  </div>
                                </li>
                                <li class="notification-cancel read-notification">
                                  <div class="notification-icon"><i class="fas fa-times-circle"></i></div>
                                  <div class="notification-content">
                                    <h3>Cancelled Transaction of 30 BTC</h3>
                                    <h4>1 hour ago</h4>
                                  </div>
                                </li>
                              </ul>
                              <div class="notification-footer">
                                <a href="JavaScript:Void(0)">Read All Notifications</a>
                              </div>
                            </div>
                          </div>
                          <div class="wallet-top-header-box user-top-detail">
                             <div class="header-wallet-ico"><img src="<?php echo e(asset('images/profile.jpg')); ?>" alt="Profile"></div>
                             <span>Welcome Back</span>
                             <h3>Mithila Mac <i class="fas fa-chevron-down"></i></h3>
                             <ul class="profile-dropdown">
                                <li><a href="profile.html"><i class="fas fa-user"></i> Profile</a></li>
                                <li><a href="wallet.html"><i class="fas fa-wallet"></i> My Wallet</a></li>
                                <li><a href=""><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                             </ul>
                          </div>
                       </div>
                    </div>
                    <div class="wallet-box-scroll">
                       <div class="wallet-bradcrumb">
                          <h2><i class="fas fa-wallet"></i> My Wallet</h2>
                       </div>
                       <div class="wallet-balance-area clearfix">
                         <div class="wallet-balance-box wallet1">
                           <div class="wallet-balance-ico">
                             <img src="assets/images/btc.png" alt="Bicoin">
                           </div>
                           <h3>Bitcoin Wallet</h3>
                           <h4>0.312373 BTC</h4>
                           <div class="my-wallet-address">
                              <span>1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</span>
                              <i class="far fa-copy"></i>
                           </div>
                         </div>
                         <div class="wallet-balance-box wallet2">
                           <div class="wallet-balance-ico">
                             <img src="assets/images/eth.png" alt="Ethereum">
                           </div>
                           <h3>Ethereum Wallet</h3>
                           <h4>1.007346 ETH</h4>
                           <div class="my-wallet-address">
                              <span>1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</span>
                              <i class="far fa-copy"></i>
                           </div>
                         </div>
                         <div class="wallet-balance-box wallet3">
                           <div class="wallet-balance-ico">
                             <img src="assets/images/ltc.png" alt="Litecoin">
                           </div>
                           <h3>Litecoin Wallet</h3>
                           <h4>2.021421 LTC</h4>
                           <div class="my-wallet-address">
                              <span>1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</span>
                              <i class="far fa-copy"></i>
                           </div>
                         </div>
                         <div class="wallet-balance-box wallet4">
                           <div class="wallet-balance-ico">
                             <img src="assets/images/bch.png" alt="Bitcoin Cash">
                           </div>
                           <h3>Bitcoin Cash Wallet</h3>
                           <h4>877393,12 BCH</h4>
                           <div class="my-wallet-address">
                              <span>1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</span>
                              <i class="far fa-copy"></i>
                           </div>
                         </div>
                         <div class="wallet-balance-box wallet5">
                           <div class="wallet-balance-ico">
                             <img src="assets/images/xrp.png" alt="Ripple">
                           </div>
                           <h3>Ripple Wallet</h3>
                           <h4>323.0421 XRP</h4>
                           <div class="my-wallet-address">
                              <span>1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</span>
                              <i class="far fa-copy"></i>
                           </div>
                         </div>
                         <div class="wallet-balance-box wallet6">
                           <div class="wallet-balance-ico">
                             <img src="assets/images/dash.png" alt="Dash">
                           </div>
                           <h3>Dashcoin Wallet</h3>
                           <h4>3.042189 DASH</h4>
                           <div class="my-wallet-address">
                              <span>1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</span>
                              <i class="far fa-copy"></i>
                           </div>
                         </div>
                       </div>
                       <!-- <div class="my-wallet-area clearfix">
                          <div class="my-wallet-box create-new-box" data-toggle="modal" data-target="#create-wallet">
                             <div class="my-wallet-ico"><i class="fas fa-plus"></i></div>
                             <h3>Create New Wallet</h3>
                          </div>
                          <div class="my-wallet-box">
                             <div class="my-wallet-name">
                                <h3>BTC Wallet Address</h3>
                             </div>
                             <div class="my-wallet-address">
                                <span>1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</span>
                                <i class="far fa-copy"></i>
                             </div>
                             <div class="my-wallet-balance">
                                <h3>Balance :- <span> 1.234567735 BTC</span></h3>
                             </div>
                          </div>
                          <div class="my-wallet-box">
                             <div class="my-wallet-name">
                                <h3>LTC Wallet Address</h3>
                             </div>
                             <div class="my-wallet-address">
                                <span>1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</span>
                                <i class="far fa-copy"></i>
                             </div>
                             <div class="my-wallet-balance">
                                <h3>Balance :- <span> 1.234567735 LTC</span></h3>
                             </div>
                          </div>
                          <div class="my-wallet-box">
                             <div class="my-wallet-name">
                                <h3>ETH Wallet Address</h3>
                             </div>
                             <div class="my-wallet-address">
                                <span>1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</span>
                                <i class="far fa-copy"></i>
                             </div>
                             <div class="my-wallet-balance">
                                <h3>Balance :- <span> 1.234567735 ETH</span></h3>
                             </div>
                          </div>
                          <div class="my-wallet-box">
                             <div class="my-wallet-name">
                                <h3>BTC Wallet Address</h3>
                             </div>
                             <div class="my-wallet-address">
                                <span>1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</span>
                                <i class="far fa-copy"></i>
                             </div>
                             <div class="my-wallet-balance">
                                <h3>Balance :- <span> 1.234567735 BTC</span></h3>
                             </div>
                          </div>
                          <div class="my-wallet-box">
                             <div class="my-wallet-name">
                                <h3>BTC Wallet Address</h3>
                             </div>
                             <div class="my-wallet-address">
                                <span>1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</span>
                                <i class="far fa-copy"></i>
                             </div>
                             <div class="my-wallet-balance">
                                <h3>Balance :- <span> 1.234567735 BTC</span></h3>
                             </div>
                          </div>
                       </div> -->
                       <div class="wallet-transaction clearfix">
                          <h2 class="dashboard-title">Last Transaction</h2>
                          <div class="wallet-transaction-box clearfix">
                             <div class="wallet-transaction-ico"><i class="fas fa-arrow-right"></i></div>
                             <div class="wallet-transaction-name">
                                <h3>Deposite</h3>
                                <span>Litecoin Wallet | Bank Transfer</span>
                             </div>
                             <div class="wallet-transaction-balance">
                                <h3>$ 405.34</h3>
                                <span>20 Jan 2020</span>
                             </div>
                          </div>
                          <div class="wallet-transaction-box clearfix">
                             <div class="wallet-transaction-ico wallet-Withdrawal"><i class="fas fa-arrow-left"></i></div>
                             <div class="wallet-transaction-name">
                                <h3>Withdrawal</h3>
                                <span>Litecoin Wallet | Bank Transfer</span>
                             </div>
                             <div class="wallet-transaction-balance">
                                <h3>$ 405.34</h3>
                                <span>20 Jan 2020</span>
                             </div>
                          </div>
                          <div class="wallet-transaction-box clearfix">
                             <div class="wallet-transaction-ico wallet-sync"><i class="fas fa-sync-alt"></i></div>
                             <div class="wallet-transaction-name">
                                <h3>BTC to Litecoin</h3>
                                <span>Litecoin Wallet</span>
                             </div>
                             <div class="wallet-transaction-balance">
                                <h3>$ 405.34</h3>
                                <span>20 Jan 2020</span>
                             </div>
                          </div>
                          <div class="wallet-transaction-box clearfix">
                             <div class="wallet-transaction-ico wallet-deposite"><i class="fas fa-arrow-right"></i></div>
                             <div class="wallet-transaction-name">
                                <h3>Deposite</h3>
                                <span>Litecoin Wallet | Bank Transfer</span>
                             </div>
                             <div class="wallet-transaction-balance">
                                <h3>$ 405.34</h3>
                                <span>20 Jan 2020</span>
                             </div>
                          </div>
                          <div class="wallet-transaction-box clearfix">
                             <div class="wallet-transaction-ico wallet-sync"><i class="fas fa-sync-alt"></i></div>
                             <div class="wallet-transaction-name">
                                <h3>BTC to Litecoin</h3>
                                <span>Litecoin Wallet</span>
                             </div>
                             <div class="wallet-transaction-balance">
                                <h3>$ 405.34</h3>
                                <span>20 Jan 2020</span>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </div>
     <!-- wallet area -->
     <!-- create wallet area -->
     <div id="create-wallet" class="modal fade theme-popup" role="dialog">
        <div class="modal-dialog">
           <!-- Modal content-->
           <div class="modal-content">
              <div class="modal-header">
                 <h4 class="modal-title">Create Wallet</h4>
                 <button type="button" class="close" data-dismiss="modal"><i class="fas fa-times"></i></button>
              </div>
              <div class="modal-body">
                 <div class="wallet-popup">
                    <form>
                       <div class="wallet-popup-box">
                          <label>Address</label>
                          <input class="theme-input" type="" name="" placeholder="1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX">
                       </div>
                       <div class="wallet-popup-box">
                          <label>Amount</label>
                          <input class="theme-input" type="" name="" placeholder="1.234567735">
                          <select>
                             <option>BTC</option>
                             <option>ETH</option>
                             <option>LTC</option>
                             <option>BCH</option>
                             <option>USDT</option>
                          </select>
                       </div>
                       <div class="wallet-btn text-right">
                          <button class="theme-btn">Create Wallet</button>
                       </div>
                    </form>
                 </div>
              </div>
           </div>
        </div>
     </div>
     <!-- create wallet area area -->
     <!-- remove wallet area -->
     <div id="remove-wallet" class="modal fade remove-theme-popup" role="dialog">
        <div class="modal-dialog">
           <!-- Modal content-->
           <div class="modal-content">
              <div class="modal-body">
                 <button type="button" class="close" data-dismiss="modal"><i class="fas fa-times"></i></button>
                 <div class="remove-popup">
                    <h3>Are you sure want to remove ?</h3>
                    <div class="remove-popuo-btn clearfix">
                       <button class="remove-btn cancel-btn" data-dismiss="modal">Cancel</button>
                       <button class="remove-btn" data-dismiss="modal">Remove</button>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </div>
     <!-- remove wallet area -->
     <!-- logout model area -->
     <div id="logout" class="modal fade remove-theme-popup" role="dialog">
        <div class="modal-dialog">
           <!-- Modal content-->
           <div class="modal-content">
              <div class="modal-body">
                 <button type="button" class="close" data-dismiss="modal"><i class="fas fa-times"></i></button>
                 <div class="remove-popup">
                    <h3>Are you sure want to logout ?</h3>
                    <div class="remove-popuo-btn clearfix">
                       <button class="remove-btn cancel-btn" data-dismiss="modal">Cancel</button>
                       <button class="remove-btn" data-dismiss="modal">Logout</button>
                    </div>
                 </div>
              </div>
           </div>
        </div>
    </div>
    <!-- logout model area -->
</div>
<?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/livewire/wallet.blade.php ENDPATH**/ ?>