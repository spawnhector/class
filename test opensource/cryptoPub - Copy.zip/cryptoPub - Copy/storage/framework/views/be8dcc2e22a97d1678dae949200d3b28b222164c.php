<div>
    <div>
        
        <div class="container px-4 mx-auto">
            <div class="space-y-4">
                <div class="flex flex-col">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['wire:model' => 'user.email','placeholder' => 'Email','errors' => $errors->first('user.email')]]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'user.email','placeholder' => 'Email','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('user.email'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
                <div class="flex flex-col">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['type' => 'password','wire:model' => 'password','placeholder' => 'Password','errors' => $errors->first('password')]]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'password','wire:model' => 'password','placeholder' => 'Password','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('password'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
                <div class="flex flex-col">
                    <button wire:click="submitForm" class="block w-full px-5 py-3 text-sm font-medium text-white bg-green-500 rounded-lg">
                        LOGIN
                    </button>
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/livewire/form/login-form.blade.php ENDPATH**/ ?>