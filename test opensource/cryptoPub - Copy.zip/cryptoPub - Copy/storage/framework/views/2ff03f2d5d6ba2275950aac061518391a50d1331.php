
<div>
<?php $attributes = $attributes->exceptProps([
    'formhead'=> false,
    'component'=>'login',
    'account'
]); ?>
<?php foreach (array_filter(([
    'formhead'=> false,
    'component'=>'login',
    'account'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
    <a class="btn1 dropdown-button mt-4" href="#login/signup"  style="position: absolute;left:230px">Continue To <?php echo e($account); ?>'s Account</a>
    <div id="login/signup" class="modalbg">
        <div class="dialog">
            <a href="#close" title="Close" class="close">X</a>
            <div>
                <div class="flex justify-center items-center flex-col mt-8">
                    
                    <div>
                        <div class="flex justify-center items-center flex-col mt-4">
                            <?php if($formhead): ?>
                                <div class="form-head"><h1 class="title grey-text text-lighten-3" style="font-size:32px;">CryptoPUB <?php echo e($account); ?></h1></div>
                            <?php endif; ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($component)->html();
} elseif ($_instance->childHasBeenRendered('ku0TP96')) {
    $componentId = $_instance->getRenderedChildComponentId('ku0TP96');
    $componentTag = $_instance->getRenderedChildComponentTagName('ku0TP96');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ku0TP96');
} else {
    $response = \Livewire\Livewire::mount($component);
    $html = $response->html();
    $_instance->logRenderedChild('ku0TP96', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/components/modal.blade.php ENDPATH**/ ?>