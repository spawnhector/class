
<?php $__env->startSection('body'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('wallet.mywallet')->html();
} elseif ($_instance->childHasBeenRendered('wzC3Wp7')) {
    $componentId = $_instance->getRenderedChildComponentId('wzC3Wp7');
    $componentTag = $_instance->getRenderedChildComponentTagName('wzC3Wp7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wzC3Wp7');
} else {
    $response = \Livewire\Livewire::mount('wallet.mywallet');
    $html = $response->html();
    $_instance->logRenderedChild('wzC3Wp7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/wallet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/extends/wallet.blade.php ENDPATH**/ ?>