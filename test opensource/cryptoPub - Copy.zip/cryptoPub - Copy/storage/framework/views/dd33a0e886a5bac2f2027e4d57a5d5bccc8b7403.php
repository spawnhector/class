<div>
    <aside class="main-sidebar">
        <!-- sidebar-->
        <section class="sidebar">

            <div class="user-profile">
                <div class="ulogo logo">
                    cryptopub
                </div>
                <div class="profile-pic">
                    
                    <div class="profile-info">
                        <h5 class="mt-15"><?php echo e(Auth::user()->UCI); ?></h5>
                        <div class="text-center d-inline-block">
                            <a href="" class="link" data-toggle="tooltip" title="" data-original-title="Settings"><i class="ion ion-gear-b"></i></a>
                            <a href="" class="link px-15" data-toggle="tooltip" title="" data-original-title="Email"><i class="ion ion-android-mail"></i></a>
                            <a href="" class="link" data-toggle="tooltip" title="" data-original-title="Logout"><i class="ion ion-power"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- sidebar menu-->
            <ul class="sidebar-menu" data-widget="tree">

                

                <li class="treeview">
                    <a href="#">
                        <i class="far fa-dot-circle"></i>
                        <span>Faucet</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-right pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        
                        <li>
                            <?php echo e(redirectP('faucet','<i class="ti-more"></i>CryptoPub',
                                "
                                    <input type='hidden' name='faucet' value='".dencrypt('CryptoPub')."'>
                                ")); ?>

                        </li>
                        <li>
                            <?php echo e(redirectP('faucet','<i class="ti-more"></i>Faucet Pay',
                                    "
                                        <input type='hidden' name='faucet' value='".dencrypt('FaucetPay')."'>
                                    ")); ?>

                        </li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="far fa-dot-circle"></i>
                        <span>Mining</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-right pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="members.html"><i class="ti-more"></i>Bitcoin</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="far fa-dot-circle"></i>
                        <span>AirDrop</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-right pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="members.html"><i class="ti-more"></i>Bitcoin</a></li>
                    </ul>
                </li>
                <li>
                    <a href="auth_login.html">
                        <i class="ti-power-off"></i>
                        <span>Log Out</span>
                    </a>
                </li>

            </ul>
        </section>
    </aside>
</div>
<?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/livewire/user/sidebar.blade.php ENDPATH**/ ?>