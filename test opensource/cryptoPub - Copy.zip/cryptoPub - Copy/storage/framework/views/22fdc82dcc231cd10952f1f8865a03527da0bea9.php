<?php $__env->startSection('body'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('landing')->html();
} elseif ($_instance->childHasBeenRendered('75VKJUk')) {
    $componentId = $_instance->getRenderedChildComponentId('75VKJUk');
    $componentTag = $_instance->getRenderedChildComponentTagName('75VKJUk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('75VKJUk');
} else {
    $response = \Livewire\Livewire::mount('landing');
    $html = $response->html();
    $_instance->logRenderedChild('75VKJUk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/welcome.blade.php ENDPATH**/ ?>