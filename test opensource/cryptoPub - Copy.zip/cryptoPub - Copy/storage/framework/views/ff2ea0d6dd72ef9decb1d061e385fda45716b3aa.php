<div>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <h3>
            Faucet
        </h3>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="breadcrumb-item"><a href="#">Members</a></li>
            <li class="breadcrumb-item active"> Faucet</li>
        </ol>
    </div>

    <div class="col-12">
        <div class="box">
            <div class="box-header">
                <h4 class="box-title"><?php echo e($faucet); ?></h4>
            </div>
        </div>
        
        

        <?php if($faucet == 'FaucetPay'): ?>
            <?php
                $count = 0;
            ?>
            <?php if($faucetList): ?>
                <?php $__currentLoopData = $faucetList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box">
                        <div class="box-header with-border">
                            <div class="flexbox mb-1">
                                <span>
                                    <i class="cc <?php echo e($key); ?>" title="<?php echo e($key); ?>" style="font-size: 41px"></i>
                                    <?php echo e($key); ?>

                                </span>
                                <span class="text-primary font-size-40"><?php echo e(count($item)); ?><span class="text-primary font-size-20"> Faucets</span></span>
                                
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div class="table-responsive">
                            <table id="faucetTable<?php echo e($count); ?>" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Reward</th>
                                        <th>Paid Today</th>
                                        <th>User's Paid Today</th>
                                        <th>Active Users</th>
                                        <th>Health</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faucet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="faucet-link" onclick="alert('<?php echo e($faucet['name']); ?>')">
                                                        <?php echo e($faucet['name']); ?>

                                                    </div>
                                                    <?php if($faucet['is_enabled'] == "1"): ?>
                                                        <span class="badge badge-pill badge-primary">Active</span>
                                                    <?php endif; ?>
                                                    <?php if($faucet['total_users_paid'] > "100"): ?>
                                                        <span class="badge badge-pill badge-success">Paying</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($faucet['reward']); ?> satoshi</td>
                                                <td><?php echo e($faucet['paid_today']); ?> USD</td>
                                                <td><?php echo e($faucet['total_users_paid']); ?></td>
                                                <td><?php echo e($faucet['active_users']); ?></td>
                                                <td>
                                                    <?php echo e($faucet['health']); ?>%
                                                    <div class="progress progress-xxs mt-10 mb-0">
                                                        <div class="progress-bar" role="progressbar" style="width: <?php echo e($faucet['health']); ?>%; height: 4px;" aria-valuenow="<?php echo e($faucet['health']); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </td>
                                            </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Name</th>
                                        <th>Position</th>
                                        <th>Office</th>
                                        <th>Age</th>
                                        <th>Start date</th>
                                        <th>Salary</th>
                                    </tr>
                                </tfoot>
                            </table>
                            </div>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <?php
                        ++$count;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
    
            <script>
                $(function () {
                    "use strict";
                    for (let index = 0; index < <?php echo e($count); ?>; index++) {
                        $('#faucetTable'+index+'').DataTable();
                    }
                }); // End of use strict
            </script>
            <script>
                function alert(params) {
                    
                    !function($) {
                        "use strict";
        
                        var SweetAlert = function() {};
        
                        //examples 
                        SweetAlert.prototype.init = function() {
                        
                        //Parameter
                        
                        swal({   
                            title: "Redirecting To External Link.",   
                            text: "You will not be able to recover this imaginary file!", 
                            type: "warning",   
                            showCancelButton: true,   
                            confirmButtonColor: "#DD6B55",   
                            confirmButtonText: "Continue",   
                            cancelButtonText: "Go Back",   
                            closeOnConfirm: false,   
                            closeOnCancel: true 
                        }, function(isConfirm){   
                            if (isConfirm) {     
                                swal("Deleted!", "Your imaginary file has been deleted.", "success");   
                            } 
                        });
        
                        },
                        //init
                        $.SweetAlert = new SweetAlert, $.SweetAlert.Constructor = SweetAlert
                    }(window.jQuery),
        
                    //initializing 
                    function($) {
                        "use strict";
                        $.SweetAlert.init()
                    }(window.jQuery);
                }
            </script>
        <?php endif; ?>

        <?php if($faucet == 'CryptoPubFaucet'): ?>
            <?php echo $__env->make('faucet.faucetinabox.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php if($faucet == 'CryptoPub'): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.cryptopub-faucet')->html();
} elseif ($_instance->childHasBeenRendered('FY1pGZE')) {
    $componentId = $_instance->getRenderedChildComponentId('FY1pGZE');
    $componentTag = $_instance->getRenderedChildComponentTagName('FY1pGZE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FY1pGZE');
} else {
    $response = \Livewire\Livewire::mount('user.cryptopub-faucet');
    $html = $response->html();
    $_instance->logRenderedChild('FY1pGZE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    </div>
    
    
</div>
<?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/livewire/user/faucet.blade.php ENDPATH**/ ?>