<div>
    <div class="flex justify-center items-center flex-col mt-8">
        
        <div class="form-head"><h1 class="title grey-text text-lighten-3" style="font-size:32px;">CryptoPUB <?php echo e($account); ?></h1></div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('login-modal',[
          'component'=>'login-signup-form'
        ])->html();
} elseif ($_instance->childHasBeenRendered('5oiVGyk')) {
    $componentId = $_instance->getRenderedChildComponentId('5oiVGyk');
    $componentTag = $_instance->getRenderedChildComponentTagName('5oiVGyk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5oiVGyk');
} else {
    $response = \Livewire\Livewire::mount('login-modal',[
          'component'=>'login-signup-form'
        ]);
    $html = $response->html();
    $_instance->logRenderedChild('5oiVGyk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/components/form.blade.php ENDPATH**/ ?>