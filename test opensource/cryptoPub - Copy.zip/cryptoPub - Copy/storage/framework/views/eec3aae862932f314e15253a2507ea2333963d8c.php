<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../images/favicon.ico">

    <title></title>

    <!-- Bootstrap 4.0-->
    <link rel="stylesheet" href="<?php echo e(asset('css/user/bootstrap.min.css')); ?>">

    <!-- theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/user/style.css')); ?>">

    <!-- Admin skins -->
    <link rel="stylesheet" href="<?php echo e(asset('css/user/skin_color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/user/main.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="https://kit.fontawesome.com/1e7319fbc7.js" crossorigin="anonymous"></script>
</head>
<body class="hold-transition dark-skin dark-sidebar sidebar-mini theme-yellow">
    <!-- Site wrapper -->
    <div class="wrapper">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.header')->html();
} elseif ($_instance->childHasBeenRendered('0RFhZVT')) {
    $componentId = $_instance->getRenderedChildComponentId('0RFhZVT');
    $componentTag = $_instance->getRenderedChildComponentTagName('0RFhZVT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0RFhZVT');
} else {
    $response = \Livewire\Livewire::mount('user.header');
    $html = $response->html();
    $_instance->logRenderedChild('0RFhZVT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <!-- Left side column. contains the logo and sidebar -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.sidebar')->html();
} elseif ($_instance->childHasBeenRendered('18rgSKq')) {
    $componentId = $_instance->getRenderedChildComponentId('18rgSKq');
    $componentTag = $_instance->getRenderedChildComponentTagName('18rgSKq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('18rgSKq');
} else {
    $response = \Livewire\Livewire::mount('user.sidebar');
    $html = $response->html();
    $_instance->logRenderedChild('18rgSKq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <div class="container-full">
              <?php if($screen == 'dashboard'): ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.dashboard')->html();
} elseif ($_instance->childHasBeenRendered('G1CQScj')) {
    $componentId = $_instance->getRenderedChildComponentId('G1CQScj');
    $componentTag = $_instance->getRenderedChildComponentTagName('G1CQScj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('G1CQScj');
} else {
    $response = \Livewire\Livewire::mount('user.dashboard');
    $html = $response->html();
    $_instance->logRenderedChild('G1CQScj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
              <?php else: ?>
                <?php if($screen == 'profile'): ?>
                  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.profile')->html();
} elseif ($_instance->childHasBeenRendered('nQop6kf')) {
    $componentId = $_instance->getRenderedChildComponentId('nQop6kf');
    $componentTag = $_instance->getRenderedChildComponentTagName('nQop6kf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nQop6kf');
} else {
    $response = \Livewire\Livewire::mount('user.profile');
    $html = $response->html();
    $_instance->logRenderedChild('nQop6kf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php endif; ?>
              <?php endif; ?>
            </div>
        </div>
        <!-- /.content-wrapper -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.setting')->html();
} elseif ($_instance->childHasBeenRendered('wmDI7YS')) {
    $componentId = $_instance->getRenderedChildComponentId('wmDI7YS');
    $componentTag = $_instance->getRenderedChildComponentTagName('wmDI7YS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wmDI7YS');
} else {
    $response = \Livewire\Livewire::mount('user.setting');
    $html = $response->html();
    $_instance->logRenderedChild('wmDI7YS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <footer class="main-footer">
            <div class="pull-right d-none d-sm-inline-block">
                <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0)">FAQ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Purchase Now</a>
                    </li>
                </ul>
            </div>
            &copy; 2019 <a href="https://www.multipurposethemes.com/">Multi-Purpose Themes</a>. All Rights Reserved.
        </footer>

    </div>
    <!-- ./wrapper -->


    <!-- jQuery 3 -->
    <script src="<?php echo e(asset('js/user/jquery-3.3.1.js')); ?>"></script>

    <!-- fullscreen -->
    <script src="<?php echo e(asset('js/user/screenfull.js')); ?>"></script>

    <!-- popper -->
    <script src="<?php echo e(asset('js/user/popper.min.js')); ?>"></script>

    <!-- Bootstrap 4.0-->
    <script src="<?php echo e(asset('js/user/bootstrap.min.js')); ?>"></script>

    <!-- SlimScroll -->
    <script src="<?php echo e(asset('js/user/jquery.slimscroll.min.js')); ?>"></script>

    <!-- FastClick -->
    <script src="<?php echo e(asset('js/user/fastclick.js')); ?>"></script>

    <!-- Crypto Admin App -->
    <script src="<?php echo e(asset('js/user/template.js')); ?>"></script>

    <!-- Crypto Admin for demo purposes -->
    <script src="<?php echo e(asset('js/user/demo.js')); ?>"></script>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\xampp\test opensource\cryptoPub\resources\views/livewire/user/index.blade.php ENDPATH**/ ?>